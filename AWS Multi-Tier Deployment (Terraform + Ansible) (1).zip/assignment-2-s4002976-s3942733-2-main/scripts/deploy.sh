#!/usr/bin/env bash
set -euo pipefail


here="$(cd "$(dirname "$0")/.."; pwd)"
tf="$here/terraform"
ans="$here/ansible"

# pull outputs
echo ">>> Reading Terraform outputs..."
BE_IP=$(terraform -chdir="$tf" output -raw backend_ip)
DB_IP=$(terraform -chdir="$tf" output -raw db_ip)
FE_IP=$(terraform -chdir="$tf" output -raw frontend_ip)
echo "backend  : $BE_IP"
echo "db       : $DB_IP"
echo "frontend : $FE_IP"

# build a temp inventory
inv="$(mktemp /tmp/inv.XXXXXX.ini)"
cat > "$inv" <<EOF
[db]
$DB_IP

[backend]
$BE_IP

[frontend]
$FE_IP
EOF
echo ">>> Inventory written to $inv"
echo
cat "$inv" | sed 's/^/  /'
echo

KEY="${SSH_KEY:-$HOME/.ssh/vockey.pem}"
USER="${SSH_USER:-ubuntu}"

if [[ ! -f "$KEY" ]]; then
  echo "ERROR: SSH key not found at $KEY"
  exit 1
fi
chmod 600 "$KEY"

wait_for_ssh() {
  local host="$1"
  echo ">>> Waiting for SSH on $host ..."
  # quick TCP wait first
  for i in {1..60}; do
    if nc -w 2 -z "$host" 22 2>/dev/null; then break; fi
    sleep 2
  done
  # try real SSH, allow cloud-init to finish
  for i in {1..20}; do
    if ssh -o StrictHostKeyChecking=no \
          -o UserKnownHostsFile=/dev/null \
          -o ConnectTimeout=5 \
          -o BatchMode=yes \
          -i "$KEY" "$USER@$host" 'cloud-init status --wait >/dev/null 2>&1 || true'; then
      echo ">>> SSH ready on $host"
      return 0
    fi
    sleep 3
  done
  echo "ERROR: SSH still not ready on $host"
  return 1
}

# Wait for each host
wait_for_ssh "$DB_IP"
wait_for_ssh "$BE_IP"
wait_for_ssh "$FE_IP"

echo
echo ">>> Running Ansible..."
ansible-playbook -i "$inv" -u "$USER" --key-file "$KEY" \
  --ssh-common-args "-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ServerAliveInterval=30 -o ConnectionAttempts=20" \
  "$ans/site.yml"

echo
echo ">>> Quick smoke tests"
echo "  Backend /status:"
curl -sS -i "http://$BE_IP/status" | head -n 20 || true
echo
echo "  Backend /posts:"
curl -sS -i "http://$BE_IP/posts" | head -n 20 || true
echo
echo "  Frontend (port 8080):"
curl -sS -i "http://$FE_IP:8080/" | head -n 20 || true

echo
echo "All done."
