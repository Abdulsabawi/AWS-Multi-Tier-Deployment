# COSC2759 Assignment 2 - Semester 2, 2025

# Services


## Backend
This is the Backend Posts Service. It is responsible for talking to the Posts DB, and exposing an internal HTTP API for managing Posts.

### Environment Variables
| Environment Variable | Purpose                                                 |
|----------------------|---------------------------------------------------------|
| PORT                 | Which port will the service listen on for HTTP requests |
| DB_USER              | Username for connecting to the Backend DB               |
| DB_PASSWORD          | Password for connecting to the Backend DB               |
| DB_HOST              | Hostname/Network address for the Backend DB             |

### Image
The Backend service image is available at `rmitdominichynes/sdo-2025:backend`.

### Dependencies
The Backend service depends on a PostgreSQL database, with the required migrations. An image for this has been provided, available at `rmitdominichynes/sdo-2025:db`.

### Database Configuration
The PostgreSQL Databse container also requires some environment variables to be configured.

|  Environment Variable        |  Purpose                                                  |
|------------------------------|-----------------------------------------------------------|
|  POSTGRES_USER               | Username for the Backend Service to use to connect        |
|  POSTGRES_PASSWORD           | Password for the Backend Service to use to connect        |
|  POSTGRES_DB                 | "posts"                                                   |

## Frontend
This is the Frontend Posts Service. It is responsible for serving a UI to users over HTTP. This UI allows them to view and manage Posts.

### Environment Variables
| Environment Variable | Purpose                                                 |
|----------------------|---------------------------------------------------------|
| PORT                 | Which port will the service listen on for HTTP requests |
| BACKEND_URL          | Fully qualified URL for reaching the Backend Service    |

### Image
The Frontend service image is available at `rmitdominichynes/sdo-2025:frontend`.


# Running The Services Locally (In Docker)
1. Run `docker compose up -d` to start the two services, and a postgres database container.
2. View the Frontend Posts Service at `http://localhost:8081`, and the Backend Posts Service at `http://localhost:8080`.

# Deploying The Services

The services can be deployed to EC2. 

Each container needs: 
- The correct environment variables configured (refer to the above sections)
- Security Groups will need to be configured to allow traffic to reach the instances. 
    - They will also need to be configured to allow the instances to talk to each other, if the services are deployed on different instances.
    - The PostgreSQL database receives inbound traffic on port `5432`
    - The ports used by the Backend and Frontend services are configurable through the `PORT` environment variable. Otherwise, it will default to port `8081`.

# Technologies Used

- **Terraform** - Infrastructure provisioning and management
- **Ansible** - Configuration management and automation
- **Docker** - Application containerization
- **AWS EC2** - Cloud compute instances
- **GitHub Actions** - CI/CD pipeline automation
- **AWS S3** - Terraform remote state backend

## Project Structure

The project is divided into three progressive sections, each building upon the previous:

### Section A – Automated Single EC2 Deployment

**Objective:** Deploy Backend and Database services on a single EC2 instance with full automation.

**Implementation:**
- Terraform configuration provisions one EC2 instance with appropriate security groups
- Security group allows inbound SSH (port 22) and HTTP (port 80) traffic
- Ansible playbook installs Docker and deploys backend and database containers
- Containers communicate via a shared Docker network
- Bash deployment script orchestrates the entire workflow: terraform init  validate  plan  apply  ansible-playbook

**Result:** A working single-instance environment where the backend API is accessible via the instance's public IP and successfully responds to HTTP requests.

### Section B – Adding the Frontend Service

**Objective:** Extend the single-instance deployment to include a complete three-tier application stack.

**Implementation:**
- Updated Ansible playbook to deploy the frontend container
- Configured environment variables (e.g., `BACKEND_URL`) for proper service communication
- Frontend container deployed on the same EC2 instance alongside backend and database
- All services interconnected through Docker networking

**Result:** A fully functional single-node application stack where users can access the frontend interface, create posts, and verify data persistence in the database.

### Section C – Multi-Instance Architecture with CI/CD Automation

**Objective:** Implement a distributed, production-ready infrastructure with complete automation.

**Implementation:**

**Infrastructure:**
- Three separate EC2 instances (one per service: frontend, backend, database)
- Advanced security group configuration:
  - Frontend: Public access + backend communication
  - Backend: Frontend + database communication
  - Database: Private, backend-only access
- Host-specific Ansible configurations for targeted deployment

**Result:** A fully automated, reproducible multi-tier infrastructure deployment. Each service runs independently with improved scalability, isolation, and reliability. The entire stack can be rebuilt automatically through git push.

##  Deployment Steps

### Step 1: Start AWS Lab and Get Credentials

Start your AWS Academy lab and retrieve your credentials from the AWS Details page.

![AWS Credentials](images/aws-credentials.png)

### Step 2: Configure AWS Credentials

```bash
#Set AWS environment variables
export AWS_ACCESS_KEY_ID="YOUR_ACCESS_KEY_ID"
export AWS_SECRET_ACCESS_KEY="YOUR_SECRET_ACCESS_KEY"
export AWS_SESSION_TOKEN="YOUR_SESSION_TOKEN"
export AWS_DEFAULT_REGION="us-east-1"
```

![AWS Configuration](images/aws-config.png)

### Step 3: Setup SSH Key

```bash
#Create and configure the SSH key
nano ~/.ssh/vockey.pem
#Paste your RSA private key here, then save and exit

#Set proper permissions
chmod 600 ~/.ssh/vockey.pem
```

### Step 4: Configure Terraform Variables

```bash
#Get your public IP
curl ifconfig.me

#Edit terraform variables
nano terraform/terraform.tfvars
```

Add the following content:
```hcl
key_pair_name = "vockey"
admin_cidr = "YOUR.IP.ADDR.HERE/32"  # Use the IP from curl ifconfig.me
```

### Step 5: Set Environment Variables

```bash
#Set the key path
export KEY_PATH=~/.ssh/vockey.pem

#Verify AWS credentials
aws sts get-caller-identity

#Store your IP for later use
MY_IP=$(curl -s ifconfig.me)
```

### Step 6: Apply Terraform Configuration

```bash
#Apply Terraform to create infrastructure
terraform -chdir=terraform apply -auto-approve
```

### Step 7: Verify SSH Connectivity

After Terraform completes, test SSH connectivity to each host:

```bash
#Replace with actual IP addresses from Terraform output
nc -vz <backend-ip> 22
nc -vz <db-ip> 22
nc -vz <frontend-ip> 22
```

Expected output for each:
```
Connection to <ip> 22 port [tcp/ssh] succeeded!
```

### Step 8: Run Deployment Script

```bash
#Execute the deployment script
bash scripts/deploy.sh
```

### Step 9: Note the EC2 IP Addresses

Example IP addresses from inventory:
```ini
[db]
3.233.234.131

[backend]
44.222.132.197

[frontend]
100.28.128.27
```

### Step 10: SSH to Instances

```bash
#SSH to any instance
ssh -i ~/.ssh/vockey.pem ubuntu@<desired-ip>
```

## Testing

### Database Setup

#### 1. SSH to the database host:

```bash
ssh -i ~/.ssh/vockey.pem ubuntu@<db-ip>
```

#### 2. Get the private IP:

```bash
hostname -I
# Example output: 172.31.76.166
```

#### 3. Check running containers:

```bash
sudo docker ps
```

#### 4. If needed, recreate the database container:

```bash
# Remove existing container
sudo docker rm -f posts-db || true

# Run new PostgreSQL container
sudo docker run -d --name posts-db \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=posts \
  -p 5432:5432 \
  postgres:14
```

### Backend Setup

#### 1. SSH to the backend host:

```bash
ssh -i ~/.ssh/vockey.pem ubuntu@<backend-ip>
```

#### 2. Get the backend's private IP:

```bash
curl -s http://169.254.169.254/latest/meta-data/local-ipv4
# Example output: 172.31.76.166
```

#### 3. Deploy the backend container:

```bash
# Remove existing container
sudo docker rm -f posts-backend || true

# Run backend container (replace DB_HOST with actual DB private IP)
sudo docker run -d --name posts-backend \
  -p 80:80 \
  -e PORT=80 \
  -e DB_HOST=172.31.64.191 \
  -e DB_PORT=5432 \
  -e DB_USER=postgres \
  -e DB_PASSWORD=postgres \
  -e DB_NAME=posts \
  rmitdominichynes/sdo-2025:backend
```

#### 4. Check backend logs:

```bash
sudo docker logs --tail 50 posts-backend
```

### database Table Creation

#### 1. SSH back to the database host

#### 2. access PostgreSQL:

```bash
sudo docker exec -it posts-db psql -U postgres -d posts
```

#### 3. Create the posts table:

```sql
CREATE TABLE IF NOT EXISTS posts (
    id SERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    content TEXT,
    body TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Exit psql
\q
```

### Backend API Testing

From the backend host:

```bash
# Test status endpoint
curl -i http://localhost/status

# Test posts endpoint
curl -i http://localhost/posts
```

![Backend Testing](images/backend-test.png)

### Frontend Setup

#### 1. SSH to the frontend host:

```bash
ssh -i ~/.ssh/vockey.pem ubuntu@<frontend-ip>
```

#### 2. Deploy the frontend container:

```bash
# Remove existing container
sudo docker rm -f posts-frontend || true

# Run frontend container (replace BACKEND_URL with actual backend private IP)
sudo docker run -d --name posts-frontend \
  -p 8080:8081 \
  -e BACKEND_URL="http://172.31.76.166" \
  rmitdominichynes/sdo-2025:frontend
```

![Frontend Deployment](images/frontend-deploy.png)
- then in your browswer  http://frontend ip:8080/

# GitHub Actions Deployment Guide

## Prerequisites (One-Time Setup)

### Step 0: Initial Requirements
- GitHub repository with your code
- AWS Academy Learner Lab access
- Your SSH private key (`vockey.pem`)
- GitHub Actions enabled on your repository

## Step 1: Configure GitHub Secrets

### Navigate to Secrets Settings
1. Go to your GitHub repository
2. Click on Settings tab
3. In the left sidebar, click Secrets and variables
4. Click Actions
5. Click New repository secret button

### Add Required Secrets

Add these four secrets with **exact names**:

#### 1. AWS_ACCESS_KEY_ID

#### 2. AWS_SECRET_ACCESS_KEY

#### 3. AWS_SESSION_TOKEN

#### 4. AWS_SSH_KEY
```
Name: AWS_SSH_KEY
Value: [Paste FULL contents of your vockey.pem file, including:]
-----BEGIN RSA PRIVATE KEY-----
[Your key content here]
-----END RSA PRIVATE KEY-----
```

#### 5. click Actions → Deploy A2 → Run workflow.

- Open Actions tab, watch logs. It will:
- Load AWS cred
- terraform apply infra
- Build inventory from outputs
- SSH + Ansible deploy containers
- Curl tests

###  Important Notes
- **Credential Rotation**: AWS Academy rotates credentials every 4 hours
- **Update Required**: Re-update the three AWS secrets when Learner Lab session expires
- **Security**: Never commit these values to your repository


## Troubleshooting

### Common Issues and Solutions
| Symptom | Cause | Fix |
|---------|-------|-----|
| `Client.UserInitiatedShutdown` | AWS terminated instance immediately after launch | Ensure `vockey` key pair exists in same region and AMI is valid |
| `No such file ~/.ssh/vockey.pem` | Missing SSH key on runner | Add `VOCKEY_PEM` secret to GitHub |
| `Ansible permission denied (publickey)` | Wrong user or key path | Use `ansible_user=ubuntu` and correct key file path |
| `Terraform recreates instances each run` | No remote state used | Enable S3 backend block for persistent state |

## Refrences
- GitHub. 2025. “How to run Ansible with AWS dynamic inventory directly via GitHub Actions on Ubuntu-Latest”. StackOverflow question. https://stackoverflow.com/questions/76645197/how-to-run-ansible-with-aws-dynamic-inventory-directly-via-github-actions-on-ubu 
- Noutsa, S. 2024. “EC2 Configuration using Ansible & GitHub Actions”. DEV Community, January 12.: https://dev.to/aws-builders/ec2-configuration-using-ansible-github-actions-25bj
- Assignment 2 Specification: Defined service requirements, multi-instance design, and marking criteria for Sections A–C.
- Terraform Labs (Weeks 3–6): Guided how we use Infrastructure-as-Code to deploy AWS EC2 instances, VPCs, security groups, and outputs.
- AWS Labs (Weeks 4–7): Provided examples of EC2 provisioning, key pair management, and network security configuration.
- Ansible Labs (Weeks 6–8): Taught us how to automate configuration tasks, install Docker, pull container images, and manage playbooks for remote hosts.
- Docker Labs (Weeks 2–4): Explained containerisation concepts and helped us run backend, database, and frontend services using pre-built Docker images.
- GitHub Actions Lab (Weeks 8–9): Introduced workflow YAML structure, environment variables, and secure AWS credential handling for CI/CD automation.
